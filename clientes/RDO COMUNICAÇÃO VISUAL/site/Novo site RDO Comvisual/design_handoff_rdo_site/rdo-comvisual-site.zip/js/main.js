(() => {
  'use strict';

  /* ------------------------------------------------------------------ */
  /* Eyes video — seamless ping-pong crossfade loop                      */
  /* ------------------------------------------------------------------ */
  function initEyesVideo() {
    const A = document.getElementById('eyeVidA');
    const B = document.getElementById('eyeVidB');
    if (!A || !B) return;

    const IN = 0.9; // skip the harsh neon opening frames
    const CROSS = 1.1; // crossfade duration (s) to hide the cut

    [A, B].forEach((v) => {
      v.muted = true;
      v.defaultMuted = true;
      v.setAttribute('muted', '');
      v.playsInline = true;
      v.loop = false;
      v.style.transition = 'opacity ' + CROSS + 's linear';
    });

    let active = A;
    let hidden = B;
    let swapping = false;

    const outAt = () => Math.max(IN + 0.2, (active.duration || 10) - CROSS);

    const start = (v) => {
      try { v.currentTime = IN; } catch (e) { /* not seekable yet */ }
      v.muted = true;
      const p = v.play();
      if (p && p.catch) p.catch(() => {});
    };

    A.style.opacity = '1';
    B.style.opacity = '0';
    start(A);

    let raf = 0;
    const tick = () => {
      if (!swapping && active.currentTime >= outAt()) {
        swapping = true;
        start(hidden);
        hidden.style.opacity = '1';
        active.style.opacity = '0';
        const oldActive = active;
        active = hidden;
        hidden = oldActive;
        setTimeout(() => {
          try { hidden.pause(); } catch (e) {}
          swapping = false;
        }, CROSS * 1000 + 60);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    // watchdog: keep the visible layer playing even if autoplay was blocked
    const watchdog = setInterval(() => {
      if (active.paused) {
        active.muted = true;
        const p = active.play();
        if (p && p.catch) p.catch(() => {});
      }
    }, 1000);

    window.addEventListener('beforeunload', () => {
      cancelAnimationFrame(raf);
      clearInterval(watchdog);
    });
  }

  /* ------------------------------------------------------------------ */
  /* Mobile nav toggle                                                    */
  /* ------------------------------------------------------------------ */
  function initMobileNav() {
    const toggle = document.getElementById('navToggle');
    const links = document.getElementById('navLinks');
    if (!toggle || !links) return;

    const close = () => {
      links.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
    };
    const open = () => {
      links.classList.add('is-open');
      toggle.setAttribute('aria-expanded', 'true');
    };

    toggle.addEventListener('click', () => {
      if (links.classList.contains('is-open')) close();
      else open();
    });

    links.querySelectorAll('a').forEach((a) => a.addEventListener('click', close));

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') close();
    });
  }

  /* ------------------------------------------------------------------ */
  /* Portfolio filter                                                    */
  /* ------------------------------------------------------------------ */
  function initPortfolioFilter() {
    const pills = document.querySelectorAll('[data-filter]');
    const cards = document.querySelectorAll('[data-cat]');
    if (!pills.length || !cards.length) return;

    pills.forEach((pill) => {
      pill.addEventListener('click', () => {
        const cat = pill.getAttribute('data-filter');

        pills.forEach((p) => p.classList.toggle('is-active', p === pill));

        cards.forEach((card) => {
          const show = cat === 'Todos' || card.getAttribute('data-cat') === cat;
          card.hidden = !show;
        });
      });
    });
  }

  /* ------------------------------------------------------------------ */
  /* Contact form — validation + submission                              */
  /* ------------------------------------------------------------------ */
  function initContactForm() {
    const form = document.getElementById('quoteForm');
    if (!form) return;

    const successEl = document.getElementById('formSuccess');
    const errorBanner = document.getElementById('formErrorBanner');
    const submitBtn = form.querySelector('.btn-submit');

    // Set this to a real endpoint (e.g. Formspree, a serverless function,
    // or your own backend) to receive submissions. Left empty, the form
    // falls back to opening the user's email client via a mailto link.
    const ENDPOINT = '';
    const DEST_EMAIL = 'contato@rdocomvisual.com.br';

    const fields = {
      name: form.querySelector('#f_name'),
      email: form.querySelector('#f_email'),
      phone: form.querySelector('#f_phone'),
    };

    function setFieldError(field, message) {
      const wrap = field.closest('.form-field');
      if (!wrap) return;
      wrap.classList.toggle('has-error', Boolean(message));
      const errEl = wrap.querySelector('.field-error');
      if (errEl) errEl.textContent = message || '';
    }

    function validate() {
      let valid = true;

      if (!fields.name.value.trim()) {
        setFieldError(fields.name, 'Informe seu nome.');
        valid = false;
      } else {
        setFieldError(fields.name, '');
      }

      const emailVal = fields.email.value.trim();
      const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailVal || !emailRe.test(emailVal)) {
        setFieldError(fields.email, 'Informe um e-mail válido.');
        valid = false;
      } else {
        setFieldError(fields.email, '');
      }

      if (!fields.phone.value.trim()) {
        setFieldError(fields.phone, 'Informe seu telefone.');
        valid = false;
      } else {
        setFieldError(fields.phone, '');
      }

      return valid;
    }

    async function submitToEndpoint(data) {
      const res = await fetch(ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error('Request failed with status ' + res.status);
    }

    function submitViaMailto(data) {
      const subject = encodeURIComponent('Pedido de orçamento — ' + data.name);
      const body = encodeURIComponent(
        'Nome: ' + data.name + '\n' +
        'Empresa: ' + data.company + '\n' +
        'E-mail: ' + data.email + '\n' +
        'Telefone: ' + data.phone + '\n' +
        'Serviço de interesse: ' + data.service + '\n\n' +
        'Detalhes do projeto:\n' + data.message
      );
      window.location.href = 'mailto:' + DEST_EMAIL + '?subject=' + subject + '&body=' + body;
    }

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      errorBanner.classList.remove('is-visible');

      if (!validate()) return;

      const data = {
        name: fields.name.value.trim(),
        company: form.querySelector('#f_company').value.trim(),
        email: fields.email.value.trim(),
        phone: fields.phone.value.trim(),
        service: form.querySelector('#f_service').value,
        message: form.querySelector('#f_msg').value.trim(),
      };

      submitBtn.disabled = true;
      submitBtn.textContent = 'Enviando...';

      try {
        if (ENDPOINT) {
          await submitToEndpoint(data);
        } else {
          submitViaMailto(data);
        }
        form.hidden = true;
        successEl.hidden = false;
      } catch (err) {
        errorBanner.textContent = 'Não foi possível enviar seu pedido agora. Tente novamente ou fale pelo WhatsApp.';
        errorBanner.classList.add('is-visible');
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Enviar pedido de orçamento';
      }
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    initEyesVideo();
    initMobileNav();
    initPortfolioFilter();
    initContactForm();
  });
})();
